let cesta;
let frutas = [];
let pontos = 0;
let velocidadeFruta = 2;
let gameOver = false;

// Cor do fundo inicial (azul claro)
let fundoColor = [135, 206, 235]; // RGB (azul claro)

function setup() {
  createCanvas(400, 600);
  cesta = new Cesta();
  frameRate(60); // Controla a taxa de atualização dos quadros
}

function draw() {
  // A cor do fundo vai escurecendo à medida que os pontos aumentam
  fundoColor[2] = constrain(235 - pontos * 0.5, 50, 235); // Diminuindo o valor do azul (componente B)
  
  // Atualiza o fundo
  background(fundoColor);

  if (gameOver) {
    // Exibe a mensagem de Game Over
    textSize(32);
    fill(255, 0, 0);
    textAlign(CENTER, CENTER);
    text("Game Over", width / 2, height / 2 - 40);
    textSize(24);
    fill(0);
    text("Pontos: " + pontos, width / 2, height / 2 + 40);
    return;  // Impede a continuação do jogo
  }

  // Atualiza e exibe as frutas
  for (let i = frutas.length - 1; i >= 0; i--) {
    frutas[i].update();
    frutas[i].show();

    // Verifica se a fruta foi coletada
    if (frutas[i].colidiuComCesta(cesta)) {
      frutas.splice(i, 1);  // Remove a fruta coletada
      pontos += 1;          // Aumenta os pontos
      velocidadeFruta += 0.2; // Aumenta a velocidade das frutas conforme as coletadas
    }
    
    // Verifica se a fruta caiu no fundo sem ser coletada
    if (frutas[i]. y > height) {
      gameOver = true;  // Ativa o estado de game over
    }
  }

  cesta.show();
  cesta.move();

  // Exibe o contador de pontos
  textSize(32);
  fill(0);
  textAlign(RIGHT);
  text("Pontos: " + pontos, width - 20, 40);

  // Adiciona novas frutas aleatoriamente
  if (frameCount % 60 === 0) {
    frutas.push(new Fruta());
  }
}

// Classe da Cesta
class Cesta {
  constructor() {
    this.x = width / 2;
    this.y = height - 50;
    this.width = 80;
    this.height = 30;
  }

  show() {
    fill(255, 0, 0);
    rect(this.x, this.y, this.width, this.height);
  }

  move() {
    // A cesta segue a posição horizontal do mouse
    this.x = mouseX - this.width / 2;

    // Limita o movimento da cesta para dentro da tela
    this.x = constrain(this.x, 0, width - this.width);
  }
}

// Classe da Fruta
class Fruta {
  constructor() {
    this.x = random(20, width - 20);  // Posição aleatória
    this.y = 0;  // Começa no topo da tela
    this.diameter = random(20, 40);  // Tamanho aleatório
    this.velocidade = velocidadeFruta;  // Velocidade inicial
  }

  show() {
    fill(255, 165, 0);  // Cor da fruta (laranja)
    ellipse(this.x, this.y, this.diameter, this.diameter);
  }

  update() {
    this.y += this.velocidade;  // Fruta cai a cada frame
  }

  colidiuComCesta(cesta) {
    let d = dist(this.x, this.y, cesta.x + cesta.width / 2, cesta.y + cesta.height / 2);
    return d < (this.diameter / 2 + cesta.width / 2);  // Checa a colisão
  }
}